package me.chemss.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import me.chemss.main.ChemssClient;
import me.chemss.modules.Module;

public class ClickGUIScreen extends Screen {
    
    public ClickGUIScreen() {
        super(Text.literal("Shiba ClickGUI"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Vẽ nền mờ tối phía sau cho game đỡ chói
        this.renderBackground(context, mouseX, mouseY, delta);

        // Vị trí đặt Menu trên màn hình
        int x = 60;
        int y = 60;

        // Vẽ khung chữ nhật Menu chính (Màu xám ấm giống ảnh Shiba của bạn)
        context.fill(x, y, x + 180, y + 200, 0xAA3C3F41); 

        // Vẽ tiêu đề Menu
        context.drawTextWithShadow(this.textRenderer, "=== SHIBA CLIENT ===", x + 30, y + 10, 0xFFFFFF);

        // Vòng lặp tự động tìm và hiện tất cả các bản Hack (Sprint, DoubleAnchor...)
        int offset = 30;
        for (Module m : ChemssClient.INSTANCE.moduleManager.getModules()) {
            // Nếu bật thì hiện chữ màu XANH LÁ [ON], tắt thì hiện chữ màu ĐỎ [OFF]
            String status = m.isToggled() ? "§a[ON]" : "§c[OFF]";
            context.drawTextWithShadow(this.textRenderer, m.getName() + " " + status, x + 15, y + offset, 0xFFFFFF);
            offset += 20;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    // Xử lý khi bạn lấy ngón tay/chuột bấm thẳng vào chữ trên Menu để Bật/Tắt Hack
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = 60;
        int y = 60;
        int offset = 30;

        for (Module m : ChemssClient.INSTANCE.moduleManager.getModules()) {
            // Kiểm tra nếu tọa độ nhấn trúng vào dòng chữ của Module đó
            if (mouseX >= x + 15 && mouseX <= x + 150 && mouseY >= y + offset && mouseY <= y + offset + 12) {
                m.toggle(); // Đổi trạng thái Bật <-> Tắt
                return true;
            }
            offset += 20;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false; // Không làm dừng game khi mở menu (để chơi mạng không bị lỗi)
    }
}
