package me.chemss.modules.combat;

import me.chemss.modules.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;

public class DoubleAnchor extends Module {

    public DoubleAnchor() {
        // Bật tắt bằng phím V
        super("DoubleAnchor", "Tu dong dat, chan damage va kich no Anchor", GLFW.GLFW_KEY_V);
    }

    @Override
    public void onTick() {
        if (!this.isToggled()) return;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // CHỨC NĂNG: STOP ON KILL (Dừng khi mục tiêu chết)
        PlayerEntity target = mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && !p.isCreative() && !p.isSpectator())
                .filter(p -> mc.player.distanceTo(p) <= 6.0f)
                .min(Comparator.comparingDouble(p -> mc.player.distanceTo(p)))
                .orElse(null);

        if (target != null && (target.isDead() || target.getHealth() <= 0)) {
            return; 
        }

        // XỬ LÝ ĐẶT VÀ NỔ
        if (mc.crosshairTarget instanceof BlockHitResult blockHit) {
            BlockPos clickedPos = blockHit.getBlockPos();
            BlockPos anchorPos = clickedPos.offset(blockHit.getSide());

            int anchorSlot = findItemInHotbar(Items.RESPAWN_ANCHOR);
            int glowstoneSlot = findItemInHotbar(Items.GLOWSTONE);
            int shieldBlockSlot = findItemInHotbar(Items.OBSIDIAN);
            if (shieldBlockSlot == -1) shieldBlockSlot = findItemInHotbar(Items.COBBLESTONE);

            if (anchorSlot == -1 || glowstoneSlot == -1) return;

            int oldSlot = mc.player.getInventory().selectedSlot;

            // CHỨC NĂNG: ANCHOR DEFENSE (Đặt block chắn damage trước mặt)
            BlockPos shieldPos = anchorPos.offset(mc.player.getHorizontalFacing().getOpposite());
            if (shieldBlockSlot != -1 && !shieldPos.equals(anchorPos)) {
                mc.player.getInventory().selectedSlot = shieldBlockSlot;
                sendPlaceBlockPacket(shieldPos);
            }

            // Tiến hành Đặt -> Nạp -> Nổ
            mc.player.getInventory().selectedSlot = anchorSlot;
            sendPlaceBlockPacket(anchorPos);

            mc.player.getInventory().selectedSlot = glowstoneSlot;
            sendInteractBlockPacket(anchorPos);

            sendInteractBlockPacket(anchorPos);

            // Trả về ô vật phẩm cũ
            mc.player.getInventory().selectedSlot = oldSlot;
        }
    }

    private int findItemInHotbar(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) {
                return i;
            }
        }
        return -1;
    }

    private void sendPlaceBlockPacket(BlockPos pos) {
        BlockHitResult hitResult = new BlockHitResult(new Vec3d(pos.getX(), pos.getY(), pos.getZ()), Direction.UP, pos, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
    }

    private void sendInteractBlockPacket(BlockPos pos) {
        BlockHitResult hitResult = new BlockHitResult(new Vec3d(pos.getX(), pos.getY(), pos.getZ()), Direction.UP, pos, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
    }
}
