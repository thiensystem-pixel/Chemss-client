package me.chemss.modules;

import java.util.ArrayList;
import java.util.List;
import me.chemss.modules.movement.Sprint;
import me.chemss.modules.combat.DoubleAnchor; // Khai báo tính năng Double Anchor từ thư mục combat

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Đăng ký cả 2 tính năng Sprint và DoubleAnchor vào hệ thống client
        modules.add(new Sprint());       
        modules.add(new DoubleAnchor()); 
    }

    public List<Module> getModules() {
        return modules;
    }

    public Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }
}

)) {
                return m;
            }
        }
        return null;
    }
}

