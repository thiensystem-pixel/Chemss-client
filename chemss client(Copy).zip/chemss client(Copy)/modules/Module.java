package me.chemss.modules;

import net.minecraft.client.MinecraftClient;

public class Module {
    // Gọi thực thể Minecraft để can thiệp vào game (người chơi, thế giới, cài đặt...)
    protected final MinecraftClient mc = MinecraftClient.getInstance(); 
    
    private String name;
    private String description;
    private int key; // Phím bấm để bật/tắt hack
    private boolean toggled; // Trạng thái hack (true = đang bật, false = đang tắt)

    public Module(String name, String description, int key) {
        this.name = name;
        this.description = description;
        this.key = key;
        this.toggled = false;
    }

    // Hàm dùng để đảo ngược trạng thái bật/tắt nhanh
    public void toggle() {
        this.toggled = !this.toggled;
        if (this.toggled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    // Viết code chạy khi BẬT hack ở đây (ví dụ: thông báo lên chat)
    public void onEnable() {}

    // Viết code chạy khi TẮT hack ở đây
    public void onDisable() {}

    // Hàm này sẽ chạy liên tục theo từng khung hình của game khi hack được bật
    public void onTick() {}

    // Các hàm lấy thông tin (Getter / Setter)
    public String getName() { return name; }
    public boolean isToggled() { return toggled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
}
