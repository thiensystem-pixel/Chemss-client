package me.chemss.modules.movement;

import me.chemss.modules.Module;
import org.lwjgl.glfw.GLFW;

public class Sprint extends Module {

    public Sprint() {
        // Đặt tên là "Sprint", mô tả, và phím bật tắt mặc định là phím L
        super("Sprint", "Tu dong chay nhanh", GLFW.GLFW_KEY_L);
    }

    // Hàm này sẽ được gọi liên tục khi game chạy
    @Override
    public void onTick() {
        // Nếu hack đang được bật (toggled == true)
        if (this.isToggled()) {
            // Nếu nhân vật có tồn tại và đang bấm nút đi tới (movementForward > 0)
            if (mc.player != null && mc.player.input.movementForward > 0) {
                // Ép Minecraft bật trạng thái chạy nhanh
                mc.player.setSprinting(true);
            }
        }
    }
}
