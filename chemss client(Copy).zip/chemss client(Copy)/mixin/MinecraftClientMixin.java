package me.chemss.mixin;

import me.chemss.main.ChemssClient;
import me.chemss.modules.Module;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(at = @At("HEAD"), method = "tick")
    private void onTick(CallbackInfo info) {
        // Cứ mỗi tick của game, nếu hack nào đang BẬT thì ép nó chạy code liên tục
        if (ChemssClient.INSTANCE.moduleManager != null) {
            for (Module m : ChemssClient.INSTANCE.moduleManager.getModules()) {
                if (m.isToggled()) {
                    m.onTick();
                }
            }
        }
    }
}
