package me.chemss.mixin;

import me.chemss.main.ChemssClient;
import me.chemss.modules.Module;
import me.chemss.gui.ClickGUIScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Keyboard;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo info) {
        if (action == 1) { // Khi bấm nút xuống
            
            // ĐÃ ĐỔI: Nếu bấm phím P thì mở Menu Shiba
            if (key == GLFW.GLFW_KEY_P) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.currentScreen == null) {
                    mc.setScreen(new ClickGUIScreen());
                }
                return;
            }

            // Các phím tắt kích hoạt nhanh (V, L)
            if (ChemssClient.INSTANCE.moduleManager != null) {
                for (Module m : ChemssClient.INSTANCE.moduleManager.getModules()) {
                    if (m.getKey() == key) {
                        m.toggle();
                    }
                }
            }
        }
    }
}
