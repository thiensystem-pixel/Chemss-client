package me.chemss.main;

import net.fabricmc.api.ClientModInitializer;

public class FabricEntrypoint implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Gọi trái tim client chạy khi vào game
        ChemssClient.INSTANCE.init();
    }
}
