package me.chemss.main;

import me.chemss.modules.ModuleManager;

public class ChemssClient {
    // Tạo cơ chế Singleton để gọi Client từ mọi nơi trong game
    public static final ChemssClient INSTANCE = new ChemssClient();
    
    public final String name = "Chemss Client";
    public final String version = "1.0";
    
    public ModuleManager moduleManager;

    // Hàm này sẽ được gọi khi Minecraft bắt đầu khởi chạy (Initialization)
    public void init() {
        System.out.println("[" + name + "] Loading Client...");
        
        // Khởi tạo trình quản lý Hack
        moduleManager = new ModuleManager();
    }
}
